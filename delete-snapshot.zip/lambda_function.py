import boto3
from datetime import datetime, timezone, timedelta

def lambda_handler(event, context):
    ec2 = boto3.client('ec2')

    # Get the current time
    now = datetime.now(timezone.utc)
   
    # Define the age limit for snapshots
    age_limit = now - timedelta(days=1)

    # List all snapshots
    snapshots = ec2.describe_snapshots(OwnerIds=['self'])['Snapshots']

    # Loop through snapshots
    for snapshot in snapshots:
        # Parse the snapshot's creation time
        creation_time = snapshot['StartTime']
        
        # Check if the snapshot is older than the age limit
        if creation_time < age_limit:
            # Print snapshot id that will be deleted - For logging
            print(f"Deleting snapshot: {snapshot['SnapshotId']}")
            
            # Delete the snapshot
            ec2.delete_snapshot(SnapshotId=snapshot['SnapshotId'])